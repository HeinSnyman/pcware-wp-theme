<?php get_header(); ?>

    <h1>woooocommmerce</h1>
    <?php woocommerce_content(); ?>
<?php get_footer(); ?>